export interface User {
  id: string;
  username: string;
  role: 'admin' | 'user';
}

export interface Purchase {
  id: string;
  itemName: string;
  quantity: number;
  costPerUnit: number;
  description: string;
  date: string;
  category: string;
}

export interface Sale {
  id: string;
  itemName: string;
  quantity: number;
  costPerUnit: number;
  description: string;
  date: string;
}

export interface Worker {
  id: string;
  name: string;
  role: string;
  phone: string;
  hireDate: string;
  status: 'active' | 'inactive';
}

export interface Task {
  id: string;
  workerId: string;
  clothingType: string;
  partType: string;
  quantity: number;
  ratePerUnit: number;
  priority: 'low' | 'medium' | 'high';
  status: 'pending' | 'in_progress' | 'completed';
  deadline: string;
  comment: string;
  date: string;
}

export interface Expense {
  id: string;
  type: 'electricity' | 'repair' | 'rent' | 'transport' | 'materials' | 'other';
  description: string;
  amount: number;
  date: string;
}

export interface Salary {
  id: string;
  workerId: string;
  amount: number;
  bonus: number;
  deductions: number;
  date: string;
  period: string;
}

export type Theme = 'light' | 'dark';
export type Language = 'ru' | 'ky';