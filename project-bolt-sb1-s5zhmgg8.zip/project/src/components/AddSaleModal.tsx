import React, { useState } from 'react';
import { Modal } from './Modal';
import { FormField } from './FormField';
import { Sale } from '../types';

interface AddSaleModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAdd: (sale: Omit<Sale, 'id'>) => void;
  language: 'ru' | 'ky';
}

export const AddSaleModal: React.FC<AddSaleModalProps> = ({
  isOpen,
  onClose,
  onAdd,
  language
}) => {
  const [formData, setFormData] = useState({
    itemName: '',
    quantity: '',
    costPerUnit: '',
    description: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (formData.itemName && formData.quantity && formData.costPerUnit) {
      onAdd({
        itemName: formData.itemName,
        quantity: Number(formData.quantity),
        costPerUnit: Number(formData.costPerUnit),
        description: formData.description,
        date: new Date().toISOString().split('T')[0]
      });
      setFormData({
        itemName: '',
        quantity: '',
        costPerUnit: '',
        description: ''
      });
      onClose();
    }
  };

  const handleClose = () => {
    setFormData({
      itemName: '',
      quantity: '',
      costPerUnit: '',
      description: ''
    });
    onClose();
  };

  return (
    <Modal isOpen={isOpen} onClose={handleClose} title="Добавить продажу">
      <form onSubmit={handleSubmit} className="space-y-4">
        <FormField
          label="Наименование товара"
          value={formData.itemName}
          onChange={(value) => setFormData({ ...formData, itemName: value })}
          placeholder="Введите наименование товара"
          required
        />
        
        <div className="grid grid-cols-2 gap-4">
          <FormField
            label="Количество"
            type="number"
            value={formData.quantity}
            onChange={(value) => setFormData({ ...formData, quantity: value })}
            placeholder="0"
            required
          />
          
          <FormField
            label="Цена за единицу"
            type="number"
            value={formData.costPerUnit}
            onChange={(value) => setFormData({ ...formData, costPerUnit: value })}
            placeholder="0"
            required
          />
        </div>
        
        <FormField
          label="Описание"
          value={formData.description}
          onChange={(value) => setFormData({ ...formData, description: value })}
          placeholder="Дополнительная информация"
        />
        
        <div className="flex gap-3 pt-4">
          <button
            type="submit"
            className="flex-1 bg-green-600 text-white py-2 px-4 rounded-lg hover:bg-green-700 transition-colors"
          >
            Добавить
          </button>
          <button
            type="button"
            onClick={handleClose}
            className="flex-1 bg-gray-300 dark:bg-gray-600 text-gray-700 dark:text-gray-300 py-2 px-4 rounded-lg hover:bg-gray-400 dark:hover:bg-gray-500 transition-colors"
          >
            Отмена
          </button>
        </div>
      </form>
    </Modal>
  );
};