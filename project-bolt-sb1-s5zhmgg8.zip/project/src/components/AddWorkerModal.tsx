import React, { useState } from 'react';
import { Modal } from './Modal';
import { FormField } from './FormField';
import { Worker } from '../types';

interface AddWorkerModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAdd: (worker: Omit<Worker, 'id'>) => void;
  language: 'ru' | 'ky';
}

const roles = [
  { value: 'cutter', label: 'Кройщик' },
  { value: 'seamstress', label: 'Швея' },
  { value: 'ironer', label: 'Утюжильщик' },
  { value: 'packer', label: 'Упаковщик' },
  { value: 'manager', label: 'Менеджер' }
];

export const AddWorkerModal: React.FC<AddWorkerModalProps> = ({
  isOpen,
  onClose,
  onAdd,
  language
}) => {
  const [formData, setFormData] = useState({
    name: '',
    role: '',
    phone: '',
    status: 'active'
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (formData.name && formData.role) {
      onAdd({
        name: formData.name,
        role: formData.role,
        phone: formData.phone,
        hireDate: new Date().toISOString().split('T')[0],
        status: formData.status as 'active' | 'inactive'
      });
      setFormData({
        name: '',
        role: '',
        phone: '',
        status: 'active'
      });
      onClose();
    }
  };

  const handleClose = () => {
    setFormData({
      name: '',
      role: '',
      phone: '',
      status: 'active'
    });
    onClose();
  };

  return (
    <Modal isOpen={isOpen} onClose={handleClose} title="Добавить сотрудника">
      <form onSubmit={handleSubmit} className="space-y-4">
        <FormField
          label="Имя сотрудника"
          value={formData.name}
          onChange={(value) => setFormData({ ...formData, name: value })}
          placeholder="Введите имя сотрудника"
          required
        />
        
        <FormField
          label="Должность"
          type="select"
          value={formData.role}
          onChange={(value) => setFormData({ ...formData, role: value })}
          options={roles}
          required
        />
        
        <FormField
          label="Телефон"
          type="tel"
          value={formData.phone}
          onChange={(value) => setFormData({ ...formData, phone: value })}
          placeholder="+996 XXX XXX XXX"
        />
        
        <FormField
          label="Статус"
          type="select"
          value={formData.status}
          onChange={(value) => setFormData({ ...formData, status: value })}
          options={[
            { value: 'active', label: 'Активен' },
            { value: 'inactive', label: 'Неактивен' }
          ]}
          required
        />
        
        <div className="flex gap-3 pt-4">
          <button
            type="submit"
            className="flex-1 bg-purple-600 text-white py-2 px-4 rounded-lg hover:bg-purple-700 transition-colors"
          >
            Добавить
          </button>
          <button
            type="button"
            onClick={handleClose}
            className="flex-1 bg-gray-300 dark:bg-gray-600 text-gray-700 dark:text-gray-300 py-2 px-4 rounded-lg hover:bg-gray-400 dark:hover:bg-gray-500 transition-colors"
          >
            Отмена
          </button>
        </div>
      </form>
    </Modal>
  );
};