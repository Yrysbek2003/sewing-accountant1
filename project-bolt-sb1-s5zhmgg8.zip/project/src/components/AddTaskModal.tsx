import React, { useState } from 'react';
import { Modal } from './Modal';
import { FormField } from './FormField';
import { Task, Worker } from '../types';

interface AddTaskModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAdd: (task: Omit<Task, 'id'>) => void;
  workers: Worker[];
  language: 'ru' | 'ky';
}

const clothingTypes = [
  { value: 'shirt', label: 'Рубашка' },
  { value: 'dress', label: 'Платье' },
  { value: 'pants', label: 'Брюки' },
  { value: 'jacket', label: 'Куртка' },
  { value: 'skirt', label: 'Юбка' }
];

const partTypes = [
  { value: 'cutting', label: 'Крой' },
  { value: 'sewing', label: 'Пошив' },
  { value: 'finishing', label: 'Отделка' },
  { value: 'ironing', label: 'Глажка' },
  { value: 'packaging', label: 'Упаковка' }
];

const priorities = [
  { value: 'low', label: 'Низкий' },
  { value: 'medium', label: 'Средний' },
  { value: 'high', label: 'Высокий' }
];

export const AddTaskModal: React.FC<AddTaskModalProps> = ({
  isOpen,
  onClose,
  onAdd,
  workers,
  language
}) => {
  const [formData, setFormData] = useState({
    workerId: '',
    clothingType: '',
    partType: '',
    quantity: '',
    ratePerUnit: '',
    priority: 'medium',
    deadline: '',
    comment: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (formData.workerId && formData.clothingType && formData.partType && formData.quantity && formData.ratePerUnit) {
      onAdd({
        workerId: formData.workerId,
        clothingType: formData.clothingType,
        partType: formData.partType,
        quantity: Number(formData.quantity),
        ratePerUnit: Number(formData.ratePerUnit),
        priority: formData.priority as Task['priority'],
        status: 'pending',
        deadline: formData.deadline,
        comment: formData.comment,
        date: new Date().toISOString().split('T')[0]
      });
      setFormData({
        workerId: '',
        clothingType: '',
        partType: '',
        quantity: '',
        ratePerUnit: '',
        priority: 'medium',
        deadline: '',
        comment: ''
      });
      onClose();
    }
  };

  const handleClose = () => {
    setFormData({
      workerId: '',
      clothingType: '',
      partType: '',
      quantity: '',
      ratePerUnit: '',
      priority: 'medium',
      deadline: '',
      comment: ''
    });
    onClose();
  };

  return (
    <Modal isOpen={isOpen} onClose={handleClose} title="Добавить задачу">
      <form onSubmit={handleSubmit} className="space-y-4">
        <FormField
          label="Сотрудник"
          type="select"
          value={formData.workerId}
          onChange={(value) => setFormData({ ...formData, workerId: value })}
          options={workers.filter(w => w.status === 'active').map(w => ({ value: w.id, label: w.name }))}
          required
        />
        
        <div className="grid grid-cols-2 gap-4">
          <FormField
            label="Тип одежды"
            type="select"
            value={formData.clothingType}
            onChange={(value) => setFormData({ ...formData, clothingType: value })}
            options={clothingTypes}
            required
          />
          
          <FormField
            label="Тип работы"
            type="select"
            value={formData.partType}
            onChange={(value) => setFormData({ ...formData, partType: value })}
            options={partTypes}
            required
          />
        </div>
        
        <div className="grid grid-cols-2 gap-4">
          <FormField
            label="Количество"
            type="number"
            value={formData.quantity}
            onChange={(value) => setFormData({ ...formData, quantity: value })}
            placeholder="0"
            required
          />
          
          <FormField
            label="Ставка за единицу"
            type="number"
            value={formData.ratePerUnit}
            onChange={(value) => setFormData({ ...formData, ratePerUnit: value })}
            placeholder="0"
            required
          />
        </div>
        
        <div className="grid grid-cols-2 gap-4">
          <FormField
            label="Приоритет"
            type="select"
            value={formData.priority}
            onChange={(value) => setFormData({ ...formData, priority: value })}
            options={priorities}
            required
          />
          
          <FormField
            label="Дедлайн"
            type="date"
            value={formData.deadline}
            onChange={(value) => setFormData({ ...formData, deadline: value })}
          />
        </div>
        
        <FormField
          label="Комментарий"
          value={formData.comment}
          onChange={(value) => setFormData({ ...formData, comment: value })}
          placeholder="Дополнительная информация"
        />
        
        <div className="flex gap-3 pt-4">
          <button
            type="submit"
            className="flex-1 bg-indigo-600 text-white py-2 px-4 rounded-lg hover:bg-indigo-700 transition-colors"
          >
            Добавить
          </button>
          <button
            type="button"
            onClick={handleClose}
            className="flex-1 bg-gray-300 dark:bg-gray-600 text-gray-700 dark:text-gray-300 py-2 px-4 rounded-lg hover:bg-gray-400 dark:hover:bg-gray-500 transition-colors"
          >
            Отмена
          </button>
        </div>
      </form>
    </Modal>
  );
};