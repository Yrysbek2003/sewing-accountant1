import React, { useState, useEffect } from 'react';
import { 
  Users, 
  ShoppingCart, 
  TrendingUp, 
  DollarSign, 
  FileText, 
  BarChart3,
  Settings,
  Moon,
  Sun,
  Globe,
  Menu,
  X,
  Plus,
  Search,
  Filter,
  Edit,
  Trash2,
  Calendar,
  TrendingDown,
  CheckSquare,
  Wallet,
  Clock,
  AlertCircle
} from 'lucide-react';
import { Toaster } from 'react-hot-toast';
import toast from 'react-hot-toast';

import { AddPurchaseModal } from './components/AddPurchaseModal';
import { AddSaleModal } from './components/AddSaleModal';
import { AddWorkerModal } from './components/AddWorkerModal';
import { AddExpenseModal } from './components/AddExpenseModal';
import { AddTaskModal } from './components/AddTaskModal';
import { TaskStatusBadge } from './components/TaskStatusBadge';
import { PriorityBadge } from './components/PriorityBadge';
import { AnalyticsChart } from './components/AnalyticsChart';
import { ExportButtons } from './components/ExportButtons';

import { Purchase, Sale, Worker, Expense, Task, Salary, Theme, Language } from './types';

const translations = {
  ru: {
    appTitle: 'Швейный Бухгалтер',
    dashboard: 'Дашборд',
    purchases: 'Закупки',
    sales: 'Продажи',
    workers: 'Сотрудники',
    tasks: 'Задачи',
    salaries: 'Зарплата',
    expenses: 'Расходы',
    analytics: 'Аналитика',
    settings: 'Настройки',
    addNew: 'Добавить',
    search: 'Поиск...',
    filter: 'Фильтр',
    totalPurchases: 'Общие закупки',
    totalSales: 'Общие продажи',
    totalWorkers: 'Сотрудники',
    totalTasks: 'Активные задачи',
    totalExpenses: 'Расходы',
    profit: 'Прибыль',
    itemName: 'Наименование',
    quantity: 'Количество',
    cost: 'Стоимость',
    costPerUnit: 'Цена за единицу',
    description: 'Описание',
    date: 'Дата',
    actions: 'Действия',
    workerName: 'Имя сотрудника',
    name: 'Имя',
    role: 'Роль',
    phone: 'Телефон',
    status: 'Статус',
    active: 'Активен',
    inactive: 'Неактивен',
    type: 'Тип',
    amount: 'Сумма',
    electricity: 'Электричество',
    repair: 'Ремонт',
    rent: 'Аренда',
    transport: 'Транспорт',
    materials: 'Материалы',
    other: 'Прочее',
    category: 'Категория',
    fabric: 'Ткань',
    accessories: 'Фурнитура',
    equipment: 'Оборудование',
    recentTransactions: 'Последние операции',
    recentTasks: 'Последние задачи',
    thisMonth: 'За этот месяц',
    edit: 'Изменить',
    delete: 'Удалить',
    confirmDelete: 'Вы уверены, что хотите удалить этот элемент?',
    cancel: 'Отмена',
    confirm: 'Подтвердить',
    clothingType: 'Тип одежды',
    partType: 'Тип работы',
    priority: 'Приоритет',
    deadline: 'Дедлайн',
    comment: 'Комментарий',
    ratePerUnit: 'Ставка за единицу',
    totalAmount: 'Общая сумма',
    pending: 'Ожидает',
    in_progress: 'В работе',
    completed: 'Завершено',
    low: 'Низкий',
    medium: 'Средний',
    high: 'Высокий',
    monthlyProfit: 'Прибыль по месяцам',
    expenseDistribution: 'Распределение расходов',
    tasksByStatus: 'Задачи по статусам',
    salesTrend: 'Тренд продаж'
  },
  ky: {
    appTitle: 'Тигүү Бухгалтери',
    dashboard: 'Башкаруу панели',
    purchases: 'Сатып алуулар',
    sales: 'Сатуулар',
    workers: 'Кызматкерлер',
    tasks: 'Тапшырмалар',
    salaries: 'Эмгек акы',
    expenses: 'Чыгашалар',
    analytics: 'Аналитика',
    settings: 'Жөндөөлөр',
    addNew: 'Кошуу',
    search: 'Издөө...',
    filter: 'Чыпка',
    totalPurchases: 'Жалпы сатып алуулар',
    totalSales: 'Жалпы сатуулар',
    totalWorkers: 'Кызматкерлер',
    totalTasks: 'Активдүү тапшырмалар',
    totalExpenses: 'Чыгашалар',
    profit: 'Пайда',
    itemName: 'Аталышы',
    quantity: 'Саны',
    cost: 'Баасы',
    costPerUnit: 'Бирдик баасы',
    description: 'Сүрөттөмө',
    date: 'Дата',
    actions: 'Аракеттер',
    workerName: 'Кызматкердин аты',
    name: 'Аты',
    role: 'Ролу',
    phone: 'Телефон',
    status: 'Абалы',
    active: 'Активдүү',
    inactive: 'Активдүү эмес',
    type: 'Түрү',
    amount: 'Сумма',
    electricity: 'Электр энергиясы',
    repair: 'Оңдоо',
    rent: 'Ижара',
    transport: 'Транспорт',
    materials: 'Материалдар',
    other: 'Башка',
    category: 'Категория',
    fabric: 'Кездеме',
    accessories: 'Аксессуарлар',
    equipment: 'Жабдуулар',
    recentTransactions: 'Акыркы операциялар',
    recentTasks: 'Акыркы тапшырмалар',
    thisMonth: 'Ушул айда',
    edit: 'Өзгөртүү',
    delete: 'Өчүрүү',
    confirmDelete: 'Бул элементти өчүрүүгө ишенесизби?',
    cancel: 'Жокко чыгаруу',
    confirm: 'Ырастоо'
  }
};

function App() {
  const [currentTab, setCurrentTab] = useState('dashboard');
  const [theme, setTheme] = useState<Theme>('light');
  const [language, setLanguage] = useState<Language>('ru');
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  
  // Modal states
  const [showPurchaseModal, setShowPurchaseModal] = useState(false);
  const [showSaleModal, setShowSaleModal] = useState(false);
  const [showWorkerModal, setShowWorkerModal] = useState(false);
  const [showExpenseModal, setShowExpenseModal] = useState(false);
  const [showTaskModal, setShowTaskModal] = useState(false);
  
  // Data states
  const [purchases, setPurchases] = useState<Purchase[]>([
    {
      id: '1',
      itemName: 'Хлопковая ткань',
      quantity: 50,
      costPerUnit: 250,
      description: 'Белая хлопковая ткань для рубашек',
      date: '2024-01-15',
      category: 'fabric'
    },
    {
      id: '2',
      itemName: 'Пуговицы',
      quantity: 200,
      costPerUnit: 5,
      description: 'Белые пластиковые пуговицы',
      date: '2024-01-16',
      category: 'accessories'
    }
  ]);

  const [sales, setSales] = useState<Sale[]>([
    {
      id: '1',
      itemName: 'Мужская рубашка',
      quantity: 10,
      costPerUnit: 1500,
      description: 'Белая классическая рубашка',
      date: '2024-01-20'
    },
    {
      id: '2',
      itemName: 'Женское платье',
      quantity: 5,
      costPerUnit: 2500,
      description: 'Летнее платье из хлопка',
      date: '2024-01-22'
    }
  ]);

  const [workers, setWorkers] = useState<Worker[]>([
    {
      id: '1',
      name: 'Анна Иванова',
      role: 'Швея',
      phone: '+996 555 123456',
      hireDate: '2024-01-01',
      status: 'active'
    },
    {
      id: '2',
      name: 'Петр Сидоров',
      role: 'Кройщик',
      phone: '+996 555 654321',
      hireDate: '2024-01-05',
      status: 'active'
    }
  ]);

  const [tasks, setTasks] = useState<Task[]>([
    {
      id: '1',
      workerId: '1',
      clothingType: 'shirt',
      partType: 'sewing',
      quantity: 20,
      ratePerUnit: 50,
      priority: 'high',
      status: 'in_progress',
      deadline: '2024-02-01',
      comment: 'Срочный заказ',
      date: '2024-01-25'
    },
    {
      id: '2',
      workerId: '2',
      clothingType: 'dress',
      partType: 'cutting',
      quantity: 15,
      ratePerUnit: 75,
      priority: 'medium',
      status: 'pending',
      deadline: '2024-02-05',
      comment: '',
      date: '2024-01-26'
    }
  ]);

  const [expenses, setExpenses] = useState<Expense[]>([
    {
      id: '1',
      type: 'electricity',
      description: 'Оплата за электричество',
      amount: 5000,
      date: '2024-01-10'
    },
    {
      id: '2',
      type: 'rent',
      description: 'Аренда помещения',
      amount: 25000,
      date: '2024-01-01'
    }
  ]);

  const t = translations[language];

  useEffect(() => {
    document.documentElement.className = theme;
  }, [theme]);

  // Calculations
  const totalPurchases = purchases.reduce((sum, p) => sum + (p.quantity * p.costPerUnit), 0);
  const totalSales = sales.reduce((sum, s) => sum + (s.quantity * s.costPerUnit), 0);
  const totalExpenses = expenses.reduce((sum, e) => sum + e.amount, 0);
  const activeTasks = tasks.filter(t => t.status !== 'completed').length;
  const profit = totalSales - totalPurchases - totalExpenses;

  // Handlers
  const handleAddPurchase = (purchase: Omit<Purchase, 'id'>) => {
    const newPurchase = { ...purchase, id: Date.now().toString() };
    setPurchases([...purchases, newPurchase]);
    toast.success('Закупка добавлена!');
  };

  const handleAddSale = (sale: Omit<Sale, 'id'>) => {
    const newSale = { ...sale, id: Date.now().toString() };
    setSales([...sales, newSale]);
    toast.success('Продажа добавлена!');
  };

  const handleAddWorker = (worker: Omit<Worker, 'id'>) => {
    const newWorker = { ...worker, id: Date.now().toString() };
    setWorkers([...workers, newWorker]);
    toast.success('Сотрудник добавлен!');
  };

  const handleAddExpense = (expense: Omit<Expense, 'id'>) => {
    const newExpense = { ...expense, id: Date.now().toString() };
    setExpenses([...expenses, newExpense]);
    toast.success('Расход добавлен!');
  };

  const handleAddTask = (task: Omit<Task, 'id'>) => {
    const newTask = { ...task, id: Date.now().toString() };
    setTasks([...tasks, newTask]);
    toast.success('Задача добавлена!');
  };

  const handleTaskStatusChange = (taskId: string) => {
    setTasks(tasks.map(task => {
      if (task.id === taskId) {
        const statusOrder: Task['status'][] = ['pending', 'in_progress', 'completed'];
        const currentIndex = statusOrder.indexOf(task.status);
        const nextIndex = (currentIndex + 1) % statusOrder.length;
        return { ...task, status: statusOrder[nextIndex] };
      }
      return task;
    }));
    toast.success('Статус задачи обновлен!');
  };

  const handleDelete = (id: string, type: 'purchase' | 'sale' | 'worker' | 'expense' | 'task') => {
    if (window.confirm(t.confirmDelete)) {
      switch (type) {
        case 'purchase':
          setPurchases(purchases.filter(p => p.id !== id));
          break;
        case 'sale':
          setSales(sales.filter(s => s.id !== id));
          break;
        case 'worker':
          setWorkers(workers.filter(w => w.id !== id));
          break;
        case 'expense':
          setExpenses(expenses.filter(e => e.id !== id));
          break;
        case 'task':
          setTasks(tasks.filter(t => t.id !== id));
          break;
      }
      toast.success('Элемент удален!');
    }
  };

  const menuItems = [
    { id: 'dashboard', label: t.dashboard, icon: BarChart3 },
    { id: 'purchases', label: t.purchases, icon: ShoppingCart },
    { id: 'sales', label: t.sales, icon: TrendingUp },
    { id: 'workers', label: t.workers, icon: Users },
    { id: 'tasks', label: t.tasks, icon: CheckSquare },
    { id: 'expenses', label: t.expenses, icon: DollarSign },
    { id: 'analytics', label: t.analytics, icon: FileText },
  ];

  const StatCard = ({ title, value, icon: Icon, color, trend }: { 
    title: string; 
    value: string; 
    icon: any; 
    color: string;
    trend?: { value: number; isPositive: boolean };
  }) => (
    <div className={`bg-white dark:bg-gray-800 rounded-xl p-6 shadow-sm border border-gray-200 dark:border-gray-700 hover:shadow-md transition-all duration-200`}>
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm font-medium text-gray-600 dark:text-gray-400">{title}</p>
          <p className="text-2xl font-bold text-gray-900 dark:text-white mt-1">{value}</p>
          {trend && (
            <div className={`flex items-center mt-2 text-sm ${trend.isPositive ? 'text-green-600' : 'text-red-600'}`}>
              {trend.isPositive ? <TrendingUp className="w-4 h-4 mr-1" /> : <TrendingDown className="w-4 h-4 mr-1" />}
              {Math.abs(trend.value)}% {t.thisMonth}
            </div>
          )}
        </div>
        <div className={`p-3 rounded-lg ${color}`}>
          <Icon className="w-6 h-6 text-white" />
        </div>
      </div>
    </div>
  );

  const renderDashboard = () => (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6">
        <StatCard
          title={t.totalPurchases}
          value={`${totalPurchases.toLocaleString()} сом`}
          icon={ShoppingCart}
          color="bg-blue-500"
          trend={{ value: 12, isPositive: false }}
        />
        <StatCard
          title={t.totalSales}
          value={`${totalSales.toLocaleString()} сом`}
          icon={TrendingUp}
          color="bg-green-500"
          trend={{ value: 8, isPositive: true }}
        />
        <StatCard
          title={t.totalWorkers}
          value={workers.filter(w => w.status === 'active').length.toString()}
          icon={Users}
          color="bg-purple-500"
        />
        <StatCard
          title={t.totalTasks}
          value={activeTasks.toString()}
          icon={CheckSquare}
          color="bg-indigo-500"
        />
        <StatCard
          title={t.profit}
          value={`${profit.toLocaleString()} сом`}
          icon={DollarSign}
          color={profit >= 0 ? "bg-emerald-500" : "bg-red-500"}
          trend={{ value: 15, isPositive: profit >= 0 }}
        />
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-sm border border-gray-200 dark:border-gray-700">
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4 flex items-center">
            <Calendar className="w-5 h-5 mr-2" />
            {t.recentTransactions}
          </h3>
          <div className="space-y-3">
            {[...purchases.slice(-3), ...sales.slice(-3)]
              .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
              .slice(0, 5)
              .map((item, index) => (
              <div key={index} className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-700 rounded-lg">
                <div className="flex items-center">
                  <div className={`p-2 rounded-lg mr-3 ${
                    'category' in item ? 'bg-blue-100 text-blue-600' : 'bg-green-100 text-green-600'
                  }`}>
                    {'category' in item ? <ShoppingCart className="w-4 h-4" /> : <TrendingUp className="w-4 h-4" />}
                  </div>
                  <div>
                    <p className="font-medium text-gray-900 dark:text-white">{item.itemName}</p>
                    <p className="text-sm text-gray-500 dark:text-gray-400">{item.date}</p>
                  </div>
                </div>
                <span className={`font-semibold ${
                  'category' in item ? 'text-red-600' : 'text-green-600'
                }`}>
                  {'category' in item ? '-' : '+'}{(item.quantity * item.costPerUnit).toLocaleString()} сом
                </span>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-sm border border-gray-200 dark:border-gray-700">
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4 flex items-center">
            <CheckSquare className="w-5 h-5 mr-2" />
            {t.recentTasks}
          </h3>
          <div className="space-y-3">
            {tasks.slice(-5).map((task) => {
              const worker = workers.find(w => w.id === task.workerId);
              return (
                <div key={task.id} className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-700 rounded-lg">
                  <div className="flex items-center">
                    <div className="p-2 rounded-lg mr-3 bg-indigo-100 text-indigo-600">
                      <CheckSquare className="w-4 h-4" />
                    </div>
                    <div>
                      <p className="font-medium text-gray-900 dark:text-white">
                        {task.clothingType} - {task.partType}
                      </p>
                      <p className="text-sm text-gray-500 dark:text-gray-400">
                        {worker?.name} • {task.quantity} шт.
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <PriorityBadge priority={task.priority} />
                    <TaskStatusBadge status={task.status} />
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );

  const renderAnalytics = () => {
    // Prepare data for charts
    const monthlyData = Array.from({ length: 12 }, (_, i) => {
      const month = new Date(2024, i, 1).toLocaleDateString('ru-RU', { month: 'short' });
      const monthSales = sales.filter(s => new Date(s.date).getMonth() === i)
        .reduce((sum, s) => sum + (s.quantity * s.costPerUnit), 0);
      const monthPurchases = purchases.filter(p => new Date(p.date).getMonth() === i)
        .reduce((sum, p) => sum + (p.quantity * p.costPerUnit), 0);
      const monthExpenses = expenses.filter(e => new Date(e.date).getMonth() === i)
        .reduce((sum, e) => sum + e.amount, 0);
      
      return {
        name: month,
        profit: monthSales - monthPurchases - monthExpenses,
        sales: monthSales
      };
    });

    const expenseData = Object.entries(
      expenses.reduce((acc, expense) => {
        acc[expense.type] = (acc[expense.type] || 0) + expense.amount;
        return acc;
      }, {} as Record<string, number>)
    ).map(([type, amount]) => ({
      name: t[type as keyof typeof t] || type,
      value: amount
    }));

    const taskStatusData = [
      { name: t.pending, value: tasks.filter(t => t.status === 'pending').length },
      { name: t.in_progress, value: tasks.filter(t => t.status === 'in_progress').length },
      { name: t.completed, value: tasks.filter(t => t.status === 'completed').length }
    ];

    return (
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white">{t.analytics}</h2>
          <ExportButtons 
            data={[...purchases, ...sales, ...expenses]} 
            filename="analytics-report" 
            title="Аналитический отчет"
          />
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <AnalyticsChart
            type="line"
            data={monthlyData}
            dataKey="profit"
            title={t.monthlyProfit}
            color="#10B981"
          />
          
          <AnalyticsChart
            type="bar"
            data={monthlyData}
            dataKey="sales"
            title={t.salesTrend}
            color="#3B82F6"
          />
          
          <AnalyticsChart
            type="pie"
            data={expenseData}
            dataKey="value"
            title={t.expenseDistribution}
          />
          
          <AnalyticsChart
            type="pie"
            data={taskStatusData}
            dataKey="value"
            title={t.tasksByStatus}
          />
        </div>
      </div>
    );
  };

  const renderTable = (data: any[], columns: string[], type: string) => {
    const filteredData = data.filter(item =>
      Object.values(item).some(value =>
        value?.toString().toLowerCase().includes(searchTerm.toLowerCase())
      )
    );

    const getModalHandler = () => {
      switch (type) {
        case 'purchases': return () => setShowPurchaseModal(true);
        case 'sales': return () => setShowSaleModal(true);
        case 'workers': return () => setShowWorkerModal(true);
        case 'expenses': return () => setShowExpenseModal(true);
        case 'tasks': return () => setShowTaskModal(true);
        default: return () => {};
      }
    };

    const getButtonColor = () => {
      switch (type) {
        case 'purchases': return 'bg-blue-600 hover:bg-blue-700';
        case 'sales': return 'bg-green-600 hover:bg-green-700';
        case 'workers': return 'bg-purple-600 hover:bg-purple-700';
        case 'expenses': return 'bg-red-600 hover:bg-red-700';
        case 'tasks': return 'bg-indigo-600 hover:bg-indigo-700';
        default: return 'bg-gray-600 hover:bg-gray-700';
      }
    };

    return (
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 overflow-hidden">
        <div className="p-6 border-b border-gray-200 dark:border-gray-700">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <h2 className="text-xl font-semibold text-gray-900 dark:text-white">
              {t[type as keyof typeof t]}
            </h2>
            <div className="flex items-center gap-3">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <input
                  type="text"
                  placeholder={t.search}
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 pr-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
              <ExportButtons 
                data={filteredData} 
                filename={type} 
                title={t[type as keyof typeof t]}
              />
              <button 
                onClick={getModalHandler()}
                className={`flex items-center gap-2 px-4 py-2 text-white rounded-lg transition-colors ${getButtonColor()}`}
              >
                <Plus className="w-4 h-4" />
                {t.addNew}
              </button>
            </div>
          </div>
        </div>
        
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50 dark:bg-gray-700">
              <tr>
                {columns.map((column) => (
                  <th key={column} className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                    {t[column as keyof typeof t] || column}
                  </th>
                ))}
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                  {t.actions}
                </th>
              </tr>
            </thead>
            <tbody className="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
              {filteredData.map((item, index) => (
                <tr key={item.id || index} className="hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors">
                  {columns.map((column) => (
                    <td key={column} className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-white">
                      {column === 'cost' || column === 'amount' || column === 'costPerUnit' || column === 'ratePerUnit'
                        ? `${item[column]?.toLocaleString()} сом`
                        : column === 'totalAmount'
                        ? `${(item.quantity * item.ratePerUnit)?.toLocaleString()} сом`
                        : column === 'status' && type === 'workers'
                        ? (
                          <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                            item[column] === 'active' 
                              ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200'
                              : 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200'
                          }`}>
                            {t[item[column] as keyof typeof t] || item[column]}
                          </span>
                        )
                        : column === 'status' && type === 'tasks'
                        ? <TaskStatusBadge status={item[column]} onClick={() => handleTaskStatusChange(item.id)} />
                        : column === 'priority'
                        ? <PriorityBadge priority={item[column]} />
                        : column === 'workerId'
                        ? workers.find(w => w.id === item[column])?.name || 'Неизвестно'
                        : column === 'type' && t[item[column] as keyof typeof t]
                        ? t[item[column] as keyof typeof t]
                        : item[column]
                      }
                    </td>
                  ))}
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                    <button className="text-blue-600 hover:text-blue-900 dark:text-blue-400 dark:hover:text-blue-300 mr-3 p-1 hover:bg-blue-50 dark:hover:bg-blue-900/20 rounded">
                      <Edit className="w-4 h-4" />
                    </button>
                    <button 
                      onClick={() => handleDelete(item.id, type as any)}
                      className="text-red-600 hover:text-red-900 dark:text-red-400 dark:hover:text-red-300 p-1 hover:bg-red-50 dark:hover:bg-red-900/20 rounded"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    );
  };

  const renderContent = () => {
    switch (currentTab) {
      case 'dashboard':
        return renderDashboard();
      case 'purchases':
        return renderTable(purchases, ['itemName', 'quantity', 'costPerUnit', 'category', 'description', 'date'], 'purchases');
      case 'sales':
        return renderTable(sales, ['itemName', 'quantity', 'costPerUnit', 'description', 'date'], 'sales');
      case 'workers':
        return renderTable(workers, ['name', 'role', 'phone', 'status'], 'workers');
      case 'tasks':
        return renderTable(tasks, ['workerId', 'clothingType', 'partType', 'quantity', 'ratePerUnit', 'totalAmount', 'priority', 'status', 'deadline'], 'tasks');
      case 'expenses':
        return renderTable(expenses, ['type', 'description', 'amount', 'date'], 'expenses');
      case 'analytics':
        return renderAnalytics();
      default:
        return renderDashboard();
    }
  };

  return (
    <div className={`min-h-screen bg-gray-50 dark:bg-gray-900 transition-colors duration-200`}>
      <Toaster 
        position="top-right"
        toastOptions={{
          duration: 3000,
          style: {
            background: theme === 'dark' ? '#374151' : '#ffffff',
            color: theme === 'dark' ? '#ffffff' : '#000000',
          },
        }}
      />
      
      {/* Header */}
      <header className="bg-white dark:bg-gray-800 shadow-sm border-b border-gray-200 dark:border-gray-700">
        <div className="px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center">
              <button
                onClick={() => setSidebarOpen(!sidebarOpen)}
                className="lg:hidden p-2 rounded-md text-gray-400 hover:text-gray-500 hover:bg-gray-100 dark:hover:bg-gray-700"
              >
                {sidebarOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
              </button>
              <h1 className="ml-2 lg:ml-0 text-xl font-bold text-gray-900 dark:text-white">
                {t.appTitle}
              </h1>
            </div>
            
            <div className="flex items-center gap-3">
              <button
                onClick={() => setTheme(theme === 'light' ? 'dark' : 'light')}
                className="p-2 rounded-lg text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
              >
                {theme === 'light' ? <Moon className="w-5 h-5" /> : <Sun className="w-5 h-5" />}
              </button>
              
              <button
                onClick={() => setLanguage(language === 'ru' ? 'ky' : 'ru')}
                className="flex items-center gap-2 p-2 rounded-lg text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
              >
                <Globe className="w-5 h-5" />
                <span className="text-sm font-medium">{language.toUpperCase()}</span>
              </button>
            </div>
          </div>
        </div>
      </header>

      <div className="flex">
        {/* Sidebar */}
        <aside className={`${
          sidebarOpen ? 'translate-x-0' : '-translate-x-full'
        } lg:translate-x-0 fixed lg:static inset-y-0 left-0 z-50 w-64 bg-white dark:bg-gray-800 border-r border-gray-200 dark:border-gray-700 transition-transform duration-200 ease-in-out lg:transition-none`}>
          <div className="flex flex-col h-full pt-16 lg:pt-0">
            <nav className="flex-1 px-4 py-6 space-y-2">
              {menuItems.map((item) => {
                const Icon = item.icon;
                return (
                  <button
                    key={item.id}
                    onClick={() => {
                      setCurrentTab(item.id);
                      setSidebarOpen(false);
                    }}
                    className={`w-full flex items-center gap-3 px-3 py-2 rounded-lg text-left transition-colors ${
                      currentTab === item.id
                        ? 'bg-blue-50 dark:bg-blue-900/20 text-blue-700 dark:text-blue-300 border border-blue-200 dark:border-blue-800'
                        : 'text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700'
                    }`}
                  >
                    <Icon className="w-5 h-5" />
                    <span className="font-medium">{item.label}</span>
                  </button>
                );
              })}
            </nav>
          </div>
        </aside>

        {/* Overlay for mobile */}
        {sidebarOpen && (
          <div
            className="lg:hidden fixed inset-0 z-40 bg-black bg-opacity-50"
            onClick={() => setSidebarOpen(false)}
          />
        )}

        {/* Main content */}
        <main className="flex-1 lg:ml-0">
          <div className="px-4 sm:px-6 lg:px-8 py-8">
            {renderContent()}
          </div>
        </main>
      </div>

      {/* Modals */}
      <AddPurchaseModal
        isOpen={showPurchaseModal}
        onClose={() => setShowPurchaseModal(false)}
        onAdd={handleAddPurchase}
        language={language}
      />
      
      <AddSaleModal
        isOpen={showSaleModal}
        onClose={() => setShowSaleModal(false)}
        onAdd={handleAddSale}
        language={language}
      />
      
      <AddWorkerModal
        isOpen={showWorkerModal}
        onClose={() => setShowWorkerModal(false)}
        onAdd={handleAddWorker}
        language={language}
      />
      
      <AddExpenseModal
        isOpen={showExpenseModal}
        onClose={() => setShowExpenseModal(false)}
        onAdd={handleAddExpense}
        language={language}
      />
      
      <AddTaskModal
        isOpen={showTaskModal}
        onClose={() => setShowTaskModal(false)}
        onAdd={handleAddTask}
        workers={workers}
        language={language}
      />
    </div>
  );
}

export default App;